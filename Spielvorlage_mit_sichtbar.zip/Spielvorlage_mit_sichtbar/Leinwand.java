import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.AffineTransform;
public class Leinwand extends JFrame implements KeyListener, MouseListener, MouseMotionListener {
    public static final int breite = 800;
    public static final int hoehe = 600;

    public Shape currentShape;
    public int offsetX;
    public int offsetY;
    public boolean isDragging;
    public boolean isRotating;
    public int rotationAngle;
    public boolean isVisible = true;
    public boolean Rechtecksichtbar;
    public boolean Kreissichtbar;
    public boolean Dreiecksichtbar;
    public Leinwand() {
        super("Leinwand");
        setSize(breite, hoehe);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setResizable(false);
        setVisible(true);
        addKeyListener(this);
        addMouseListener(this);
        addMouseMotionListener(this);
    }

    @Override
    public void paint(Graphics g) {
        super.paint(g);
        Graphics2D g2d = (Graphics2D) g.create();
        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        if (Rechtecksichtbar && currentShape instanceof Rechteck) {
            g2d.setColor(Color.RED);
            drawShape(g2d, currentShape);
        }
        if (Dreiecksichtbar && currentShape instanceof Dreieck ) {
            g2d.setColor(Color.GREEN);
            drawShape(g2d, currentShape);
        }
        if (Kreissichtbar && currentShape instanceof Kreis ) {
            g2d.setColor(Color.BLUE);
            drawShape(g2d, currentShape);
        }
        g2d.dispose();
    }

    public void drawShape(Graphics2D g2d, Shape shape) {
        AffineTransform transform = new AffineTransform();
        transform.translate(shape.x, shape.y);
        transform.rotate(Math.toRadians(rotationAngle), shape.breite / 2.0, shape.hoehe / 2.0);
        g2d.transform(transform);
        shape.draw(g2d);
    }

    public void setzeSichtbarkeit(boolean visible) {
        isVisible = visible;
        repaint();
    }

    /**
     *  Zeichnet ein Rechteck mit der x-Position,y-Position und der Breite und Hoehe 
     */
    public void Rechteck(int x, int y, int breite, int hoehe) {
        currentShape = new Rechteck(x, y, breite, hoehe);
        Rechtecksichtbar = true;
        repaint();
    }

    public void zeigeRechteck()
    {
        Rechtecksichtbar = true;
        repaint();
    }

    public void versteckeRechteck() {
        Rechtecksichtbar = false;
        repaint();
    }

    public void loescheRechteck() {
        currentShape = null;
        repaint();
    }
    public void RechteckFarbeaendern(Color farbe) {
        if (currentShape instanceof Rechteck) {
            Rechteck rechteck = (Rechteck) currentShape;
            rechteck.farbe = farbe;
            repaint();
        }
    }
    /**
     *   Zeichnet ein Dreieck zwischen x1,y1 und x2,y2 und x3,y3
     */
    public void Dreieck(int x1, int y1, int x2, int y2, int x3, int y3) {
        currentShape = new Dreieck(x1, y1, x2, y2, x3, y3);
        Dreiecksichtbar = true;
        repaint();
    }

    public void zeigeDreieck() {
        Dreiecksichtbar = true;
        repaint();
    }

    public void versteckeDreieck() {
        Dreiecksichtbar = false;
        repaint();
    }

    public void loescheDreieck() {
        currentShape = null;
        repaint();
    }
    public void DreieckFarbeaendern(Color farbe) {
        if (currentShape instanceof Dreieck) {
            Dreieck dreieck = (Dreieck) currentShape;
            dreieck.farbe = farbe;
            repaint();
        }
    }
    /**
     *  Zeichnet einen Kreis mit der x-Position und y-Position und dem Kreisradius
     */
    public void Kreis(int x, int y, int radius) {
        currentShape = new Kreis(x, y, radius);
        Kreissichtbar = true;
        repaint();
    }

    public void zeigeKreis() {
        Kreissichtbar = true;
        repaint();
    }

    public void versteckeKreis() {
        Kreissichtbar = false;
        repaint();
    }

    public void loescheKreis() {
        currentShape = null;
        repaint();
    }

    @Override
    public void keyTyped(KeyEvent e) {
        // Nicht verwendet, da wir nur keyReleased und keyPressed benoetigen
    }

    @Override
    public void keyPressed(KeyEvent e) {
        int keyCode = e.getKeyCode();
        System.out.println("Taste gedrueckt: " + KeyEvent.getKeyText(keyCode));
        if (keyCode == KeyEvent.VK_R) {
            Rechteck(100, 100, 200, 150);
        } else if (keyCode == KeyEvent.VK_C) {
            Kreis(300, 300, 100);
        } else if (keyCode == KeyEvent.VK_T) {
            Dreieck(200, 200, 400, 200, 300, 400);
        }
    }

    @Override
    public void keyReleased(KeyEvent e) {
        // Nicht verwendet, aber erforderlich fuer die KeyListener-Schnittstelle
    }

    @Override
    public void mouseClicked(MouseEvent e) {
        int x = e.getX();
        int y = e.getY();
        System.out.println("Mausposition: x=" + x + ", y=" + y);
    }

    @Override
    public void mousePressed(MouseEvent e) {
        int x = e.getX();
        int y = e.getY();
        if (currentShape != null && currentShape.contains(x, y)) {
            offsetX = x - currentShape.x;
            offsetY = y - currentShape.y;
            isDragging = true;
        }
    }

    @Override
    public void mouseReleased(MouseEvent e) {
        isDragging = false;
        isRotating = false;
    }

    @Override
    public void mouseEntered(MouseEvent e) {
        // Nicht verwendet
    }

    @Override
    public void mouseExited(MouseEvent e) {
        // Nicht verwendet
    }

    @Override
    public void mouseDragged(MouseEvent e) {
        if (isDragging && currentShape != null) {
            int x = e.getX() - offsetX;
            int y = e.getY() - offsetY;
            currentShape.x = x;
            currentShape.y = y;
            repaint();
        } else if (isRotating && currentShape != null) {
            int mouseX = e.getX();
            int mouseY = e.getY();
            double dx = mouseX - currentShape.getCenterX();
            double dy = mouseY - currentShape.getCenterY();
            rotationAngle = (int) Math.toDegrees(Math.atan2(dy, dx));
            repaint();
        }
    }

    @Override
    public void mouseMoved(MouseEvent e) {
        // Nicht verwendet
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(Leinwand::new);
    }

    
    // Beispielimplementierungen fuer Rechteck, Kreis und Dreieck

    public abstract static class Shape {
        public int x;
        public int y;
        public int breite;
        public int hoehe;
        
        public Shape(int x, int y, int breite, int hoehe) {
            this.x = x;
            this.y = y;
            this.breite = breite;
            this.hoehe = hoehe;
            
        }
        public Color FarbeCodieren(String farbe)
    {
        farbe = farbe.toLowerCase();
        switch (farbe)
        {
            case "wei�":
            case "weiss":
                return Color.WHITE;
            case "rot":
                return Color.RED;
            case "gr�n":
            case "gruen":
                return Color.GREEN;
            case "blau":
                return Color.BLUE;
            case "gelb":
                return Color.YELLOW;
            case "magenta":
                return Color.MAGENTA;
            case "cyan":
                return Color.CYAN;
            case "grau":
                return Color.GRAY;
            case "schwarz":
                return Color.BLACK;
            default:
                return Color.BLACK;
        }
    }
        public abstract void draw(Graphics2D g2d);

        public boolean contains(int x, int y) {
            return x >= this.x && x <= this.x + breite && y >= this.y && y <= this.y + hoehe;
        }

        public double getCenterX() {
            return x + breite / 2.0;
        }

        public double getCenterY() {
            return y + hoehe / 2.0;
        }
    }

    public static class Rechteck extends Shape {
        public Color farbe;
        public Rechteck(int x, int y, int breite, int hoehe) {
            super(x, y, breite, hoehe);
            
        }

        @Override
        public void draw(Graphics2D g2d) {
            g2d.setColor(Color.RED);
            g2d.fillRect(0, 0, breite, hoehe);
            farbe = Color.RED;
        }
    }

    public static class Kreis extends Shape {
        public int radius;
        public Color farbe;
        public Kreis(int x, int y, int radius) {
            super(x - radius, y - radius, radius * 2, radius * 2);
            this.radius = radius;
        }

        @Override
        public void draw(Graphics2D g2d) {
            g2d.setColor(Color.BLUE);
            g2d.fillOval(0, 0, breite, hoehe);
        }
    }

    public static class Dreieck extends Shape {
        public int x1;
        public int y1;
        public int x2;
        public int y2;
        public int x3;
        public int y3;
        public Color farbe;
        public Dreieck(int x1, int y1, int x2, int y2, int x3, int y3) {
            super(Math.min(Math.min(x1, x2), x3), Math.min(Math.min(y1, y2), y3),
                Math.max(Math.max(x1, x2), x3) - Math.min(Math.min(x1, x2), x3),
                Math.max(Math.max(y1, y2), y3) - Math.min(Math.min(y1, y2), y3));
            this.x2 = x2 - x;
            this.y2 = y2 - y;
            this.x3 = x3 - x;
            this.y3 = y3 - y;
        }

        @Override
        public void draw(Graphics2D g2d) {
            g2d.setColor(Color.GREEN);
            int[] xPoints = {0, x2, x3};
            int[] yPoints = {0, y2, y3};
            g2d.fillPolygon(xPoints, yPoints, 3);
        }
    }
}