
/**
 * Diese Klasse kann verwendet werden, um ein Menue zu erstellen.
 * 
 * @author Maxi :)
 * @version 1.0
 */
public class Interface
{
    private int leben;
    private int geld;
    
    private Rechteck lebensanzeige;
    private Text geldanzeige;
    
    /**
     * Konstruktor für Objekte der Klasse Interface
     */
    public Interface()
    {
        leben = 100;
        geld = 0;
    }
    
    public void lebensanzeigeErstellen()
    {
        lebensanzeige = new Rechteck();
        lebensanzeige.GroesseSetzen(80,15);
        lebensanzeige.FarbeSetzen("rot");
    }
    
    public void geldanzeigeErstellen()
    {
        geldanzeige = new Text();
        geldanzeige.TextSetzen(String.valueOf(geld));
        geldanzeige.TextGroesseSetzen(20);
        geldanzeige.Verschieben(0,15);
    }
}