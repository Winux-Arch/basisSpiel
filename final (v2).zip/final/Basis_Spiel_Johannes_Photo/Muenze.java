
/**
 * Ein Dekoratives Objekt als Beispiel wie man Dinge erstellt.
 * 
 * @author Maxi :) 
 * @version 1.0
 */
public class Muenze
{
    /**
     * Attribute wie der Wert, die Farbe und Weiteres wird hier gesetzt. Dabei muessen
     * auch die Bestandteile der Muenze einzeln aufgelistet werden
     */
    private String farbe;
    private int hoehe;
    private int breite;
    private int positionX;
    private int positionY;
    private int wert;
    
    private Kreis outline;
    private Kreis basis;
    private Rechteck inline;
    
    public Muenze()
    {
        positionX = 20;
        positionY = 25;
        farbe = "gelb";
        hoehe = 40;
        breite = hoehe/2;
        wert = 0;
        
        erstellen(wert);
    }
    
    public Muenze(int wert)
    {
        positionX = 20;
        positionY = 25;
        farbe = "gelb";
        hoehe = 40;
        breite = hoehe/2;
        wert = wert;
        
        erstellen(wert);
    }
    
    public void erstellen(int wert)
    {
        /**
         * Zuerst wird der Rand erstellt, der ein Hohlkreis sein soll.
         */        
        outline = new Kreis();
        outline.GroesseSetzen(breite, hoehe);
        outline.FarbeSetzen("schwarz");
        outline.PositionSetzen(positionX, positionY);
        
        /**
         * Dannach wird die Grundflaeche, also die gelbe Flaeche in der Mitte erstellt.
         */
        basis = new Kreis();
        basis.GroesseSetzen(breite-5, hoehe-7);
        basis.FarbeSetzen(farbe);
        basis.PositionSetzen(positionX+2, positionY+3);
        
        /**
         * Zuletzt wird ein Rechteck auf der Muenze plaziert fuer ein besseres Design.
         */
        inline = new Rechteck();
        inline.GroesseSetzen(breite/5, hoehe/2);
        inline.FarbeSetzen("schwarz");
        inline.PositionSetzen(positionX+8, positionY+9);
        
        /**
         * Im Notfall koennen alle Objekte auch in den Vorder-/Hintergrund gebracht werden.
         */
        sichtbarkeitReparieren();
    }
    
    /**
     * Mit dieser Methode kann die Muenze eingesammelt werden, dabei wird am Ende der 
     * Wert der Muenze ausgegeben. Dies kann zum Beispiel zum Geldstand des Spielers 
     * hinzugefuegt werden.
     */
    public int einsammeln() throws InterruptedException
    {
        /**
         * Dies stellt die Animation dar, die beim aufsammeln angezeigt wird.
         */
        for (int i=0; i<6; i++)
        {
            outline.Verschieben(0,-1);
            basis.Verschieben(0,-1);
            inline.Verschieben(0,-1);
            /**
             * Sollte die folgende Zeile in einer Methode oder im Konstruktor enthalten sein,
             * bitte nach den runden Klammern noch "throws InterruptedException" hinzufuegen.
             * Diese bewirkt einen kurzen Delay von n Millisekunden, in diesem Fall 45ms.
             * 
             * z.B. name() throws InterruptedException
             * 
             */
            Thread.sleep(45);
        }
        outline.Verschieben(0,2);
        basis.Verschieben(0,2);
        inline.Verschieben(0,2);
        Thread.sleep(100);
        /**
         * Die Sichtbarkeit der einzelnen Bestandteile wird in invertierter Reihenfolge
         * entfernt, um ein realistischeres Aufsammeln zu erzeugen (kaum sichtbar).
         */
        inline.SichtbarkeitSetzen(false);
        basis.SichtbarkeitSetzen(false);
        outline.SichtbarkeitSetzen(false);
        
        return wert;
    }
    
    public void sichtbarkeitReparieren()
    {
        outline.GanzNachHintenBringen();
        inline.GanzNachVornBringen();
    }
    
    public void PositionenGeben()
    {
        System.out.println("Outline | x: "+String.valueOf(outline.x)+"; y: "+String.valueOf(outline.y));
        System.out.println("Basis   | x: "+String.valueOf(basis.x)+"; y: "+String.valueOf(basis.y));
        System.out.println("Inline  | x: "+String.valueOf(inline.x)+"; y: "+String.valueOf(inline.y));
    }
}
