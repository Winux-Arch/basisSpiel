
/**
 * Die Werkbank ist wie ein Experimentiertisch,
 * hier kann man Klassen und Methoden aus der Leinwand abrufen und ver�ndern,
 * neue Methoden kann man auch erstellen 
 * 
 * @author (Johannes Preissinger) 
 * @version (1.1)
 */
public class Werkbank
{
    Leinwand l1 = new Leinwand();
    
    public Werkbank()
    {
        
    }
    /**
     * Hier wird ein Rechteck mit x, y-Position, Breite und Hoehe
     * aus der Klasse Leinwand erstellt
     * 
     */
    public void Rechteck()
    {
    //x,y,breite,hoehe
    l1.Rechteck(200,200,100,80);
    
    
    
    }
    /**
     * Hier wird ein Kreis mit x, y-Position und Radius
     * aus der Klasse Leinwand erstellt
     * 
     */
    public void Kreis(int x,int y,int radius)
    {
    //x,y,Radius
    l1.Kreis(x,y,radius);
    
    
    }
    /**
     * Hier wird ein Dreieck mit dem ersten x,y-Punkt, dem zweiten x,y-Punkt
     * und dem dritten x,y-Punkt, (zwischen den Punkten werden Linien gezeichnet)
     * aus der Klasse Leinwand erstellt
     * 
     */
    public void Dreieck(int x1, int y1, int x2, int y2, int x3, int y3)
    {
        //x-Punkt1,y-Punkt1,x-Punkt2,y-Punkt-2,x-Punkt-3,y-Punkt-3 
        l1.Dreieck(x1,y1,x2,y2,x3,y3);
    
    
    }
    public void Leinwandreinigen()
    {
    l1.loescheRechteck();
    l1.loescheKreis();
    l1.loescheDreieck();
    
    
    
    }
}
