import java.awt.*;
import javax.swing.*;
/**
 * @author (Johannes Preissinger) 
 * @version (1.0)
 */
public class main 
    { //muss noch irgendwie in Zeichenebene integriert werden
    JFrame frame = new JFrame("Bild");
    public main()
    {
        frame.setSize(600,600);
        frame.setLocation(0,0);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setContentPane(new Panel());
        frame.setVisible(true);    
    }
}