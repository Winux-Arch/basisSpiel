import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.AffineTransform;

public class Leinwand extends JFrame implements KeyListener, MouseListener, MouseMotionListener {
    private static final int WIDTH = 800;
    private static final int HEIGHT = 600;

    private Shape currentShape;
    private int offsetX;
    private int offsetY;
    private boolean isDragging;
    private boolean isRotating;
    private int rotationAngle;

    public Leinwand() {
        super("Leinwand");
        setSize(WIDTH, HEIGHT);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setResizable(false);
        setVisible(true);
        addKeyListener(this);
        addMouseListener(this);
        addMouseMotionListener(this);
    }

    @Override
    public void paint(Graphics g) {
        super.paint(g);
        if (currentShape != null) {
            Graphics2D g2d = (Graphics2D) g.create();
            g2d.setColor(Color.RED);
            g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            AffineTransform transform = new AffineTransform();
            transform.translate(currentShape.x, currentShape.y);
            transform.rotate(Math.toRadians(rotationAngle), currentShape.width / 2.0, currentShape.height / 2.0);
            g2d.transform(transform);
            currentShape.draw(g2d);
            g2d.dispose();
        }
    }

    public void createRectangle(int x, int y, int width, int height) {
        currentShape = new Rectangle(x, y, width, height);
        repaint();
    }

    public void createCircle(int x, int y, int radius) {
        currentShape = new Circle(x, y, radius);
        repaint();
    }

    public void createTriangle(int x1, int y1, int x2, int y2, int x3, int y3) {
        currentShape = new Triangle(x1, y1, x2, y2, x3, y3);
        repaint();
    }

    @Override
    public void keyTyped(KeyEvent e) {
        // Nicht verwendet, da wir nur keyReleased und keyPressed benötigen
    }

    @Override
    public void keyPressed(KeyEvent e) {
        int keyCode = e.getKeyCode();
        System.out.println("Taste gedrückt: " + KeyEvent.getKeyText(keyCode));
        if (keyCode == KeyEvent.VK_R) {
            createRectangle(100, 100, 200, 150);
        } else if (keyCode == KeyEvent.VK_C) {
            createCircle(300, 300, 100);
        } else if (keyCode == KeyEvent.VK_T) {
            createTriangle(200, 200, 400, 200, 300, 400);
        }
    }

    @Override
    public void keyReleased(KeyEvent e) {
        // Nicht verwendet, aber erforderlich für die KeyListener-Schnittstelle
    }

    @Override
    public void mouseClicked(MouseEvent e) {
        int x = e.getX();
        int y = e.getY();
        System.out.println("Mausposition: x=" + x + ", y=" + y);
    }

    @Override
    public void mousePressed(MouseEvent e) {
        int x = e.getX();
        int y = e.getY();
        if (currentShape != null && currentShape.contains(x, y)) {
            offsetX = x - currentShape.x;
            offsetY = y - currentShape.y;
            isDragging = true;
        }
    }

    @Override
    public void mouseReleased(MouseEvent e) {
        isDragging = false;
        isRotating = false;
    }

    @Override
    public void mouseEntered(MouseEvent e) {
        // Nicht verwendet
    }

    @Override
    public void mouseExited(MouseEvent e) {
        // Nicht verwendet
    }

    @Override
    public void mouseDragged(MouseEvent e) {
        if (isDragging && currentShape != null) {
            int x = e.getX() - offsetX;
            int y = e.getY() - offsetY;
            currentShape.x = x;
            currentShape.y = y;
            repaint();
        } else if (isRotating && currentShape != null) {
            int mouseX = e.getX();
            int mouseY = e.getY();
            double dx = mouseX - currentShape.getCenterX();
            double dy = mouseY - currentShape.getCenterY();
            rotationAngle = (int) Math.toDegrees(Math.atan2(dy, dx));
            repaint();
        }
    }

    @Override
    public void mouseMoved(MouseEvent e) {
        // Nicht verwendet
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(Leinwand::new);
    }

    // Beispielimplementierungen für Rechteck, Kreis und Dreieck

    private abstract static class Shape {
        protected int x;
        protected int y;
        protected int width;
        protected int height;

        public Shape(int x, int y, int width, int height) {
            this.x = x;
            this.y = y;
            this.width = width;
            this.height = height;
        }

        public abstract void draw(Graphics2D g2d);

        public boolean contains(int x, int y) {
            return x >= this.x && x <= this.x + width && y >= this.y && y <= this.y + height;
        }

        public double getCenterX() {
            return x + width / 2.0;
        }

        public double getCenterY() {
            return y + height / 2.0;
        }
    }

    private static class Rectangle extends Shape {
        public Rectangle(int x, int y, int width, int height) {
            super(x, y, width, height);
        }

        @Override
        public void draw(Graphics2D g2d) {
            g2d.setColor(Color.RED);
            g2d.fillRect(0, 0, width, height);
        }
    }

    private static class Circle extends Shape {
        private int radius;

        public Circle(int x, int y, int radius) {
            super(x - radius, y - radius, radius * 2, radius * 2);
            this.radius = radius;
        }

        @Override
        public void draw(Graphics2D g2d) {
            g2d.setColor(Color.BLUE);
            g2d.fillOval(0, 0, width, height);
        }
    }

    private static class Triangle extends Shape {
        private int x2;
        private int y2;
        private int x3;
        private int y3;

        public Triangle(int x1, int y1, int x2, int y2, int x3, int y3) {
            super(Math.min(Math.min(x1, x2), x3), Math.min(Math.min(y1, y2), y3),
                    Math.max(Math.max(x1, x2), x3) - Math.min(Math.min(x1, x2), x3),
                    Math.max(Math.max(y1, y2), y3) - Math.min(Math.min(y1, y2), y3));
            this.x2 = x2 - x;
            this.y2 = y2 - y;
            this.x3 = x3 - x;
            this.y3 = y3 - y;
        }

        @Override
        public void draw(Graphics2D g2d) {
            g2d.setColor(Color.GREEN);
            int[] xPoints = {0, x2, x3};
            int[] yPoints = {0, y2, y3};
            g2d.fillPolygon(xPoints, yPoints, 3);
        }
    }
}