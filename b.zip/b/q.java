
/**
 * Beschreiben Sie hier die Klasse q.
 * 
 * @author (Ihr Name) 
 * @version (eine Versionsnummer oder ein Datum)
 */
public class q
{
    Leinwand l1 = new Leinwand();
    
    public q()
    {
        
    }
    public void Rechteck()
    {
    l1.createRectangle(20,20,20,20);
    
    
    
    }
    
}
