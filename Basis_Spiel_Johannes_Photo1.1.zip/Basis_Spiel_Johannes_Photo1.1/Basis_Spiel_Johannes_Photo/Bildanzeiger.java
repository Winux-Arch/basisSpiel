import java.awt.Graphics;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.Dimension;
import java.awt.Frame;
import java.io.File;

public class Bildanzeiger extends Frame {

private Image bild;

public Bildanzeiger(String dateiname) {
bild = Toolkit.getDefaultToolkit().getImage("bilder" + File.separator + dateiname);
setSize(new Dimension(600, 600));
setVisible(true);
}

public void paint(Graphics g) {
g.drawImage(bild, 0, 0, this);
}

public static void main(String[] args) {
Bildanzeiger anzeiger = new Bildanzeiger("OIP.jpg");
}
}