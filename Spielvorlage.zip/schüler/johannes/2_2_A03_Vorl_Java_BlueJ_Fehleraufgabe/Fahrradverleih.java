
/**
 * Ein einfacher Fahrradverleih mit zunächst zwei Kunden und drei Rädern
 * 
 * @author Klaus Reinold
 * @version 1.0
 */
class Fahrradverleih
{
    /** Referenzattribut für das erste Fahrrad */
    Fahrrad fahrrad1;
    /** Referenzattribut für das zweite Fahrrad */
    Fahrrad fahrrad2;
    /** Referenzattribut für das dritte Fahrrad */
    Fahrrad fahrrad3;
    /** Referenzattribut für den ersten Kunden */
    Kunde kunde1;
    /** Referenzattribut für den zweiten Kunden */
    Kunde kunde2;

    /**
     * Konstruktor des Fahrradverleihs
     */
    Fahrradverleih()
    {
        fahrrad1 = new Fahrrad("Mountainbike", "blau");
        fahrrad2 = new Fahrrad("E-Bike", "schwarz");
        fahrrad3 = new Fahrrad("Single Speed", "grün");
        
        kunde1 = new Kunde("Albert Ross", "Ameisenstraße 1, Turing");
        kunde2 = new Kunde("Hella Wahnsinn", "Milchstraße 7, Infohausen");
        
    }
    
    /**
     * Methode zum Ausleihen eines Fahrrads
     * @param fahrradNummer Nummer des Fahrrads
     * @param kundenNummer Nummer des Kunden
     */
    void Ausleihen(int fahrradNummer, int kundenNummer)
    {
        Fahrrad fahrrad;
        if(fahrradNummer == 1)
        {
            fahrrad = fahrrad1;
        }
        else
        {
            if(fahrradNummer == 2)
            {
                fahrrad = fahrrad2;
            }
            else 
            {
                fahrrad = fahrrad3;
            }
        }
        
        Kunde kunde;
        if(kundenNummer == 1)
        {
            kunde = kunde1;
        }
        else
        {
            kunde = kunde2;
        }
        
        AuftragsbestätigungDrucken(kunde, fahrrad);
    }
    
    /**
     * Druck eines Leihauftrags
     * @param k Kunde, der ausleiht
     * @param f das ausgeliehene Fahrrad
     */
    void AuftragsbestätigungDrucken(Kunde k, Fahrrad f)
    {
       Text überschrift;
       überschrift = new Text();
       überschrift.TextGrößeSetzen(20);
       überschrift.TextSetzen("Auftragsbestätigung");
       überschrift.PositionSetzen(10, 20);
       
       String kundenName;
       kundenName = k.NameGeben();
       
       Text kundenname;
       kundenname = new Text();
       kundenname.TextSetzen("Entleiher: " + kundenName);
       kundenname.PositionSetzen(10, 40);
       
       String adresse;
       adresse = k.AdresseGeben();
       
       Text kundenadresse;
       kundenadresse = new Text();
       kundenadresse.TextSetzen("Anschrift: " + adresse);
       kundenadresse.PositionSetzen(10, 55);
       
       String fahrradtyp;
       fahrradtyp = f.TypGeben();
       
       Text fahrradTyp;
       fahrradTyp = new Text();
       String farbe;
       farbe = f.FarbeGeben();
       fahrradTyp.TextSetzen("Fahrradtyp: " + fahrradtyp + " Farbe: "+ farbe);
       fahrradTyp.PositionSetzen(10, 90);
       
       FahrradZeichnen(farbe);
    } 

    /*
     * Stellt ein Fahrrad grafisch dar
     * @param farbe Farbe des Fahrrads
     */
    void FahrradZeichnen(String farbe)
    {
        int x, y;
        x = 30;
        y = 120;
        Kreis k1;
        k1 = new Kreis();
        k1.PositionSetzen(x + 20, y + 30);
        k1.RadiusSetzen(10);
        k1.FarbeSetzen("schwarz");
        
        k1 = new Kreis();
        k1.PositionSetzen(x + 20, y + 30);
        k1.RadiusSetzen(8);
        k1.FarbeSetzen("weiss");
        
        k1 = new Kreis();
        k1.PositionSetzen(x + 55, y + 30);
        k1.RadiusSetzen(10);
        k1.FarbeSetzen("schwarz");
        
        k1 = new Kreis();
        k1.PositionSetzen(x + 55, y + 30);
        k1.RadiusSetzen(8);
        k1.FarbeSetzen("weiss");
        
        Dreieck d;
        d = new Dreieck();
        d.PositionSetzen(x+40, y+10);
        d.FarbeSetzen(farbe);
        d.GrößeSetzen(40, 20);
        d.Drehen(180);
        
        Rechteck lenker;
        lenker = new Rechteck();
        lenker.FarbeSetzen("schwarz");
        lenker.GrößeSetzen(30, 2);
        lenker.PositionSetzen(x+8, y+8);
        lenker.Drehen(45);
    }
}
