
/**
 * Daten des Kunden
 * 
 * @author Klaus Reinold
 * @version 1.0
 */
class Kunde
{
    /** Name des Kunden */
    String name;
    /** Adresse des Kunden */
    String adresse;

    /**
     * Konstruktor für Objekte der Klasse Kunde
     * @param nameNeu Name des Kunden
     * @param adresseNeu Adresse des Kunden
     */
    Kunde(String nameNeu, String adresseNeu)
    {
        name = nameNeu;
        adresse = adresseNeu;
    }

    /**
     * Liefert den Namen des Kunden
     * @return Name des Kunden
     */
    
    String NameGeben()
    {
        return "Karl Kopf";
    }

    /**
     * Liefert die Adresse des Kunden
     * @return Adresse des Kunden
     */
    String AdresseGeben()
    {
        return adresse;
    }
}
