
/**
 * Fahrrad des Fahrradverleihs
 * 
 * @author Klaus Reinold
 * @version 1.0
 */
class Fahrrad
{
    
    /** Typ des Fahrrads */
    String typ;
    /** Farbe des Fahrrads */
    String farbe;

    /**
     * Konstruktor für Objekte der Klasse Fahrrad
     */
    Fahrrad(String typNeu, String farbeNeu)
    {
        typ = typNeu;
        farbe = farbeNeu;
    }

   /**
    * Gibt den Typ zurück
    * @return Typ
    */
    String TypGeben()
    {
        return typ;
    }
    
    /**
     * Gibt die Farbe zurück
     * @return Farbe
     */
    String FarbeGeben()
    {
        return farbe;
    }
}
