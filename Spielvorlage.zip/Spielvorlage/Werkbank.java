 

 


/**
 * Beschreiben Sie hier die Klasse q.
 * 
 * @author (Ihr Name) 
 * @version (eine Versionsnummer oder ein Datum)
 */
public class Werkbank
{
    Leinwand l1 = new Leinwand();
    
    public Werkbank()
    {
        
    }
    public void Rechteck()
    {
    //x,y,breite,hoehe
    l1.Rechteck(20,20,50,20);
    
    
    
    }
    public void Kreis()
    {
    //x,y,Radius
    l1.Kreis(10,10,50);
    
    
    }
    public void Dreieck()
    {
        //x-Punkt1,y-Punkt1,x-Punkt2,y-Punkt-2,x-Punkt-3,y-Punkt-3 
        l1.Dreieck(30,30,60,30,30,30);
    
    
    }
}
