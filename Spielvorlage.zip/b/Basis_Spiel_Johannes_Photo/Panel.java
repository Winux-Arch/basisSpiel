import java.awt.*;
import javax.swing.*;
/**
 * Beschreiben Sie hier die Klasse Bild_einfüger.
 * 
 * @author (Johannes Preissinger) 
 * @version (1.0)
 */
public class Panel extends JPanel
{
    public Panel(){}
    public void paintComponent(Graphics g)
    {
        ImageIcon bild = new ImageIcon("OIP.jpg");
        g.drawImage(bild.getImage(),300,300,408,243,null);
        //ignorieren
        //setIcon(new ImageIcon());
        //setBounds(175, 152, 227, 97);
        //bild.add (bild);
    }
}
