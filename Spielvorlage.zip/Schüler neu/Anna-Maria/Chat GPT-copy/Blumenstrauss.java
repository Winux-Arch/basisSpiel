
/**
 * Beschreiben Sie hier die Klasse KLasse.
 * 
 * @author (Ihr Name) 
 * @version (eine Versionsnummer oder ein Datum)
 */
public class Blumenstrauss
{
    // Attribute
    private int GänseblümchenAnzahl;
    private int RosenAnzahl; 

    // Konstruktor(en)    
    public Blumenstrauss()
    {
        GänseblümchenAnzahl = 3;
        RosenAnzahl = 5;

    }

    public int BlumenanzahAnzeigen(String Blumenart)
    {
        if (Blumenart == "Gänseblümchen")
        {
            return GänseblümchenAnzahl;
        }
        if (Blumenart == "Rosen" )
        {
            return RosenAnzahl;
        }
        return 1;
    }
    
    // Methoden
    
}
