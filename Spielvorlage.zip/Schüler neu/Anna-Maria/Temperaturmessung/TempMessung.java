
/**
 * Beschreiben Sie hier die Klasse TempMessung.
 * 
 * @author (Ihr Name) 
 * @version (eine Versionsnummer oder ein Datum)
 */
public class TempMessung
{
    // Attribute
    private int höchstbetrag;
    private int temp [];
    private int niedrigsterbetrag;
    // Konstruktor(en)    
    public TempMessung()
    {
        temp  = new int [365];
        höchstbetrag = 0;
    }

    public void zufälligeTemp()
    {
        for (int i = 0; i < temp.length; i++)
        {
            temp [i] = -20 + new java.util.Random().nextInt(40);   
        }
        for (int i = 0; i < temp.length; i++)
        {
            System.out.println( (i+1)+":"+ temp [i]);
        }

    }

    public void höchsteTemp() 
    {
        for (int i = 0; i < temp.length; i++)
        {
            if (temp [i]> temp [höchstbetrag])
            {
                i = höchstbetrag;
            }
            else 
            {

            }
        }
        System.out.println("höchster Temperaturwert:"+ höchstbetrag);
    }

    public void niedrigsteTemp() 
    {
        for (int i = 0; i < temp.length; i++)
        {
            if (temp [i]< temp [niedrigsterbetrag])
            {
                i = niedrigsterbetrag;
            }
            else 
            {

            }
        }
        System.out.println("höchster Temperaturwert:"+ höchstbetrag);
    }

    // Methoden

}
