
/**
 * Beschreiben Sie hier die Klasse Rechteck.
 * 
 * @author (Ihr Name) 
 * @version (eine Versionsnummer oder ein Datum)
 */
public class Rechteck
{
    // Attribute
    int linksObenX;
    int linksObenY;
    int länge;
    int breite;
    int flächeninhalt;
    int umfang;
    int diagonallänge;
    int temp;
    
    
    
    

    // Konstruktor(en)    
    public Rechteck()
    {linksObenX = 10;
     linksObenY = 10;
     länge = 40;
     breite = 20;
    

    }


    // Methode
    
    int flaecheninhaltberechnen()
    {return länge * breite;
        
        
}
int umfangeberechnen()
{return länge*2 + breite*2;
}
void größeSetzen(int längeNeu, int breiteNeu)
{ länge = längeNeu;
  breite = breiteNeu;     
    
    
} void verschieben (int deltaX, int deltaY)
{linksObenX = deltaX;
linksObenY = deltaY;
}
void kippen(int temp)
{ temp = breite;
    breite = länge;
    länge = temp;
}}
    
