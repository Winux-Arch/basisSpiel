
public class Auto
{
    // Attribute
    int maximalgeschwindigkeit;
    int ps;
    int preis;
    int anzahlsitze;
    String marke;
    
    // Konstruktor(en)    
    public Auto()
    {
    maximalgeschwindigkeit = 250;
    ps = 560; 
    preis = 250000;
    anzahlsitze = 2;
    marke = "Ferrari";
    }


    // Methoden

}
