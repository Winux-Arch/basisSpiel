
/**
 * Beschreiben Sie hier die Klasse Rechteck.
 * 
 * @author (Ihr Name) 
 * @version (eine Versionsnummer oder ein Datum)
 */
public class Rechteck
{
    // Attribute

    
    // Konstruktor(en)    
    public Rechteck()
    {

    }


    // Methoden

}
