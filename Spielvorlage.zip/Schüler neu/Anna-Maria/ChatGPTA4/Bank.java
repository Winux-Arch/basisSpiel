
/**
 * Beschreiben Sie hier die Klasse Bank.
 * 
 * @author (AnnaMaria) 
 * @version (eine Versionsnummer oder ein Datum)
 */
public class Bank
{
    // Attribute
    private int KontostandSabrina;
    private int KontostandAnnaMaria;
    private int KontostandIrem;
    private int KontostandAnika;
    
    
    private int hoehe;
    private int breite;
    private int xPosition;
    private int yPosition;
    private String farbe;
    private boolean istSichtbar;

    // Konstruktor(en)    
    public Bank()
    {
        KontostandSabrina = 20;
        KontostandAnnaMaria = 3000;
        KontostandIrem = 50;
        KontostandAnika= 3 ;
        
        hoehe = 30;
        breite = 15;
        xPosition = 0;
        yPosition = 0;
        farbe = "rot";
        istSichtbar = false;
    }

    // Methoden
    public int Einzahlen (String Konto, int Betrag)
    {
        if (Konto == "Sabrina")
        {
            KontostandSabrina = KontostandSabrina + Betrag;
            return KontostandSabrina;
        }
        if (Konto == "AnnaMaria")
        {
            KontostandAnnaMaria = KontostandAnnaMaria + Betrag;
            return KontostandAnnaMaria;
        }
        if (Konto == "Irem")
        {
            KontostandIrem = KontostandIrem + Betrag;
            return KontostandIrem;
        }
        if (Konto == "Anika")
        {
            KontostandAnika = KontostandAnika + Betrag;
            return KontostandAnika;
        }
        return 1;
    }

    public int Auszahlen (String Konto, int Betrag)
    {
        if (Konto == "Sabrina" )
        {
            KontostandSabrina = KontostandSabrina - Betrag;
            return KontostandSabrina;
        }
        if (Konto == "AnnaMaria")
        {
            KontostandAnnaMaria = KontostandAnnaMaria - Betrag;
            return KontostandAnnaMaria;
        }
        if (Konto == "Irem")
        {
            KontostandIrem = KontostandIrem - Betrag;
            return KontostandIrem;
        }
        if (Konto == "Anika")
        {
            KontostandAnika = KontostandAnika - Betrag;
            return KontostandAnika;
        }
        return 1;
    }

    public int KontostandEinsehen (String Konto)
    {
        if (Konto == "Sabrina" )
        {
            return KontostandSabrina;
        }
        if (Konto == "AnnaMaria")
        {
            return KontostandAnnaMaria;
        }
        if (Konto == "Irem")
        {
            return KontostandIrem;
        }
        if (Konto == "Anika")
        {
            return KontostandAnika;
        }
        return 1;
    }

    private void zeichnen() 
    {
        if (istSichtbar) {
            Leinwand leinwand = Leinwand.gibLeinwand();
            leinwand.zeichne(this, farbe, new Rectangle (xPosition, yPosition,
                    breite, hoehe));
            leinwand.warte(10);
        }
    }

    /**
     * Lösche dieses Rechteck vom Bildschirm.
     */
    private void loeschen() 
    {
        if (istSichtbar) {
            Leinwand leinwand = Leinwand.gibLeinwand();
            leinwand.entferne(this);
        }
    }

    public void warte(int millisekunden) {
        try {
            Thread.sleep(millisekunden);
        } catch (Exception e) {
            // Exception ignorieren
        }
    }
}
