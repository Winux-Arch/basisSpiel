
/**
 * Beschreiben Sie hier die Klasse Bank.
 * 
 * @author (Ihr Name) 
 * @version (eine Versionsnummer oder ein Datum)
 */
public class Bank
{
    // Attribute
    private int KontostandSabrina;
    private int KontostandAnnaMaria;
    private int KontostandIrem;
    private int KontostandAnika;

    // Konstruktor(en)    
    public Bank()
    {
        KontostandSabrina = 20;
        KontostandAnnaMaria = 3000;
        KontostandIrem = 50;
        KontostandAnika = 3;

    }

    // Methoden
    public void Einzahlen (String Konto, int Betrag)
    {
        if (Konto == "Sabrina")
        {
            KontostandSabrina = KontostandSabrina + Betrag
        }
    }
}
