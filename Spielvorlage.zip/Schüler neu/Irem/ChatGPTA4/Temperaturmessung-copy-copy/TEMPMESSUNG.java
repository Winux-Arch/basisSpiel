
/**
 * Beschreiben Sie hier die Klasse TEMPMESSUNG.
 * 
 * @author (Ihr Name) 
 * @version (eine Versionsnummer oder ein Datum)
 */
public class TEMPMESSUNG
{
    // Attribute
    public int T [];
    public int d;
    public boolean l;
    public boolean o;

    // Konstruktor(en)    
    public TEMPMESSUNG()
    {
    T = new int [365];
    l = false;
    o = false;
    
    }


    // Methoden
public void nT()
{
    for (int i=0; i<365 ; i++)
    {
        T[i] = -20 + new Random().nextInt(61);
    }  
}
public void maxT()
{
   l= false;
   for (int i=0 ; i<365 ; i++)
   {
       if (T[i] == 40)
       { 
           System.out.printIn("Tag" + p + " " + T[p]);
        }
    }
}


