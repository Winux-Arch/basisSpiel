import java.util.*;
/**
 * Beschreiben Sie hier die Klasse Lotto.
 * 
 * @author (Ihr Name) 
 * @version (eine Versionsnummer oder ein Datum)
 */
public class Lotto
{
    // Attribute
    public int[] Zahlen;
    public int[] alteZahlen;
    public boolean[] a;
    public int s;

    // Konstruktor(en)    
    public Lotto()
    {
        Zahlen = new int[7];
        alteZahlen = new int[7];
        a = new boolean[49];
        s = 0;
        while ( s!=7)
        {
            s = 0;
            for (int i=0 ; i<6 ; i++)
            {
                Zahlen [i] = 0;
            }
            for (int i=0 ; i<49 ; i++)
            {
                a [i] = false;
            }
            for (int i=0 ; i<7 ; i++)
            {
                Zahlen [i] = new Random().nextInt(49);
            }
            for (int i=0 ; i<7 ; i++)
            {
                a[Zahlen [i]] = true;
            }
            for (int i=0 ; i<49 ; i++)
            {
                if (a[i] == true)
                {
                    s++;
                }
            }
        }
        for (int i=0 ; i<7 ; i++)
        {
            System.out.println("Zahl "+ (i+1) +" = " + Zahlen[i]);
        }
    }
    // Methoden
    public void Ausgeben()
    {
        for (int i=0 ; i<7 ; i++)
        {
            System.out.println("Zahl "+ (i+1) +" = " + Zahlen[i]);
        }
    }
    
    public void Merken()
    {
        for (int i=0 ; i<7 ; i++)
        {
            alteZahlen[i] = Zahlen[i];
        }
    }
    
    public void alteAusgeben()
    {
        for (int i=0 ; i<7 ; i++)
        {
            System.out.println("Zahl "+ (i+1) +" = " + alteZahlen[i]);
        }
    }
}
