
/**
 * Beschreiben Sie hier die Klasse k.
 * 
 * @author (Ihr Name) 
 * @version (eine Versionsnummer oder ein Datum)
 */
public class k
{
    // Attribute

    
    // Konstruktor(en)    
    public k()
    {
        
    }


    // Methoden

}
