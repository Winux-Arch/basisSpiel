import java.util.*;
/**
 * Beschreiben Sie hier die Klasse Tempmessung.
 * 
 * @author (Ihr Name) 
 * @version (eine Versionsnummer oder ein Datum)
 */
public class Tempmessung
{
    // Attribute
    public int T[];
    public int d;
    public boolean l;
    public boolean o;

    // Konstruktor(en)    
    public Tempmessung()
    {
        T = new int[365];
        l= false;
        o= false;
    }

    // Methoden
    public void nT()
    {
        for (int i=0 ; i<365 ; i++)
        {
            T[i] = -20 + new Random().nextInt(61);
        }
    }

    public void minmaxT()
    {
        Comparable max=null;
        Comparable min=null;
        if(T.length>0)
            max=T[0];
        min=max;
        for(Comparable c:T)
        {
            if(min.compareTo(c)>0)
                min=c;
            if(max.compareTo(c)<0)
                max=c;

        }
        System.out.println(min);
        System.out.println(max);
    }

    public void maxT()
    {
        l= false;
        for (int i=0 ; i<365 ; i++)
        {
            if (T[i] == 40)
            {
                System.out.println("Tag " + i + " " + T[i]);
                l = true;
            }

        }

        if (l == false)
        {
            for (int p=0 ; p<365 ; p++)
            {
                if (T[p] == 39)
                {
                    System.out.println("Tag " + p + " " + T[p]);
                }
            }
        }

    }
    
    public void minT()
    {
        o= false;
        for (int i=0 ; i<365 ; i++)
        {
            if (T[i] == -20)
            {
                System.out.println("Tag " + i + " " + T[i]);
                o = true;
            }

        }

        if (o == false)
        {
            for (int p=0 ; p<365 ; p++)
            {
                if (T[p] == -19)
                {
                    System.out.println("Tag " + p + " " + T[p]);
                }
            }
        }

    }
    // Tim war hier
    public void Durchschnitt()
    {
        d = 0;
        for (int i=0 ; i<365 ; i++)
        {
            d = d + T[i];
        }
        System.out.println (d / 365);
    }
}
