import java.util.*;
/**
 * 
 */
public class Tempmessung

{
    public int Temperaturen[];

    public Tempmessung()
{ 
        Temperaturen = new int [365];
}

    public void nT()
{
    for (int i=0;i<365;i++)
    { 
      Temperaturen[i] = -20 + new Random().nextInt(61);
    }
}
    
    public void höchsteT()
{ 
    for (int i=0 ; i<356 ;i++)
    { 
        if (Temperaturen[i]==40)
        { 
         System.out.println("Tag"+ i + ""+ Temperaturen [i]);
        }
    }
}
}