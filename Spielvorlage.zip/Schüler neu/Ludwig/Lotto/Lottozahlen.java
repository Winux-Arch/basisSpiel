
/**
 * Beschreiben Sie hier die Klasse Lottozahlen.
 * 
 * @author (Ihr Name) 
 * @version (eine Versionsnummer oder ein Datum)
 */
public class Lottozahlen
{
    // Attribute

    
    // Konstruktor(en)    
    public Lottozahlen()
    {

    }


    // Methoden

}
