
/**
 * Beschreiben Sie hier die Klasse TEMPMESSUNG.
 * 
 * @author (Ihr Name) 
 * @version (eine Versionsnummer oder ein Datum)
 */
public class TEMPMESSUNG
{
    // Attribute
    int[] temperatur;
    // Konstruktor(en)    
    public TEMPMESSUNG()
    {
        temperatur= new int[366];
    }
    // Methoden
    public void temperaturändern()
    {
        for (int i=0;i<366;i++)
        {
            temperatur[i] = new java.util.Random().nextInt(1234);
        }
    }
    public void höchstetemperatur()
    {
        int Tag = 0;
        int temp = 0;
            for(int i=0;i<366;i++)
            {
                if(temperatur[i]>temp)
                {
                    temp = temperatur[i];
                    Tag = i+1;
                }
            }
        System.out.println( "Die höchste Temperatur wurde am " + Tag + ". Tag gemessen");
    }
    public void niedrigtemperatur()
    {
        int temp = 1234;
            for(int i=0;i<366;i++)
            {
                if(temperatur[i]<temp)
                {
                    temp = temperatur[i];
                }
            }
        System.out.println( "Die Niedrigste Temperatur waren " + temp + " Grad");
    }
    public void durchschnitt()
    {
        int gesamt = 0;
            for(int i=0;i<366;i++)
            {
                gesamt = gesamt+temperatur[i];
            }
        System.out.println( "Die Durchschnittstemperatur waren " + gesamt/366 + " Grad");
    }
}
