
/**
 * Klasse zur AkkustandsAnzeige.
 * 
 * @author Peter Brichzin
 * @version 23.10.20
 */
class AkkustandsAnzeige extends Ereignisbehandlung
{
    // Attribute
    int ladezustand;  //in Prozent

    // Referenzattribute
    Rechteck anzeigeLeer;
    Rechteck anzeigeSchwach;
    Rechteck anzeigeVoll;

    /**
     * Konstruktor für Objekte der Klasse AkkustandsAnzeige
     */
    AkkustandsAnzeige()
    {
        super();
        ladezustand = 100;
        anzeigeLeer.GrößeSetzen(10, 30);
        anzeigeLeer.PositionSetzen(0,0);
        anzeigeLeer.FarbeSetzen("grün");
        anzeigeLeer.SichtbarkeitSetzen(true);

        anzeigeSchwach.GrößeSetzen(10, 30);
        anzeigeSchwach.PositionSetzen(20,0);
        anzeigeSchwach.FarbeSetzen("grün");
        anzeigeSchwach.SichtbarkeitSetzen(true);

        anzeigeVoll.GrößeSetzen(10, 30);
        anzeigeVoll.PositionSetzen(20,20);
        anzeigeVoll.FarbeSetzen("grün");
        anzeigeVoll.SichtbarkeitSetzen(true);
    }

    /**
     * Setzt den Ladezustand auf den neuen Wert und aktualisiert die Anzeige
     * @param ladezustandNeu neuer Ladezustand
     */
    void LadezustandAktualisieren(int ladezustandNeu)
    { 
        ladezustand = ladezustandNeu;
        AnzeigeAktualisieren();
    }

    /**
     * Lädt die Batterie auf 100% auf
     */
    void Aufladen()
    { 
        ladezustand = 100;
    }

    /**
     * Aktualisiert die Anzeige gemäß des momentanen Ladezustands
     */
    void AnzeigeAktualisieren()
    {

        // hier ergänzen, wann die Anzeige ihr Aussehen wechselt
    }

    /**
     * Verringert den Ladezustand um 1%
     */
    @Override void TaktImpulsAusführen()
    {
        if(ladezustand >0)
        {
            ladezustand = ladezustand-1;
            AnzeigeAktualisieren();
        }
        System.out.println(ladezustand + "%");

    }
}
