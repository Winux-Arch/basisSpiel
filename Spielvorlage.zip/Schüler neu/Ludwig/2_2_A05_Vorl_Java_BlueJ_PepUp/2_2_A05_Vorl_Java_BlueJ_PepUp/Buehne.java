
/**
 * Das Haus, das renoviert werden soll, mit der Umgebung.
 * 
 * @author Klaus Reinold
 * @version 1.0
 */
class Buehne extends Ereignisbehandlung
{
    Rechteck himmel;
    Rechteck boden;
    Rechteck haus;
    Rechteck fenster;
    Rechteck tür;
    Dreieck dach;
    Kreis dachfenster; 
    Kreis sonne;

    int i;

    /**
     * Konstruktor für Objekte der Klasse Bühne
     */
    Buehne()
    {
        i = 0;

        himmel = new Rechteck();
        himmel.PositionSetzen(0, 0);
        himmel.GrößeSetzen(800, 300);
        himmel.FarbeSetzen("magenta");

        boden = new Rechteck();
        boden.PositionSetzen(0, 300);
        boden.GrößeSetzen(800, 300);
        boden.FarbeSetzen("braun");

        haus = new Rechteck();
        haus.PositionSetzen(260, 180);
        haus.GrößeSetzen(250, 150);
        haus.FarbeSetzen("grau");

        fenster = new Rechteck();   
        fenster.PositionSetzen(280, 200);
        fenster.GrößeSetzen(130, 70);
        fenster.FarbeSetzen("weiss");
        fenster.Drehen(-15);

        tür = new Rechteck();   
        tür.PositionSetzen(450, 220);
        tür.GrößeSetzen(70, 110);
        tür.FarbeSetzen("orange");

        dachfenster = new Kreis();
        dachfenster.PositionSetzen(380, 150);
        dachfenster.RadiusSetzen(10);
        dachfenster.FarbeSetzen("weiss");

        dach = new Dreieck();
        dach.PositionSetzen(285, 50);
        dach.GrößeSetzen(250, 80);

        new Kreis();
    }

    /**
     * Das Dach muss um 100 nach rechts und 50 nach unten.
     */
    void DachVerschieben()
    {
        for(int i = 0; i<50 ;i++)
        {
            dach.Verschieben(2,1);
        }
    }

    /**
     * Das Dachfenster muss in den Vordergrund gerückt werden.
     */
    void DachfensterNachVorneHolen()
    {
        dachfenster.NachVornBringen();
    }
    
     /**
     * Das Haus soll weiß gestrichen werden.
     */
    void HausTünchen()
    {
        haus.FarbeSetzen("weiss");
    }

    /**
     * Die Tür muss um 20 nach links.
     */
    void TürNachLinks()
    {
        //Code ergänzen!
    }

    /**
     * Das Fenster muss um 15 Grad gedreht werden.
     */
    void FensterDrehen()
    {
        //Code ergänzen!
    }

    /**
     * Der Boden muss begrünt werden.
     */
    void BodenBegrünen()
    {
        //Code ergänzen!
    }

    /**
     * Der Himmel muss blau werden.
     */
    void HimmelFärben()
    {
        //Code ergänzen!
    }

    /**
     * Die Sonne muss gelb und passender positioniert werden.
     */
    void SonneKorrigieren()
    {
        //erst bei Aufgabe c) bearbeiten!
        //sonne.FarbeSetzen("gelb");
        //sonne.PositionSetzen(700,80);
    }

    /**
     * Taktsteuerung des Films
     */
    @Override void TaktImpulsAusführen()
    {
        switch(i)
        {
            case 0: 
            DachVerschieben();
            break;
            case 1: 
            DachfensterNachVorneHolen();
            break;
            case 2: 
            HausTünchen();
            break;
            case 3:
            TürNachLinks();
            break;
            case 4: 
            FensterDrehen();
            break;
            case 5: 
            BodenBegrünen();
            break;
            case 6: 
            HimmelFärben();
            break;
            case 7:
            SonneKorrigieren();
        }
        i = i + 1;
    }

}
