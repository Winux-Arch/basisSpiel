
/**
 * Beschreibt eine Lampe für eine Ampel
 *
 * @author Albert Wiedemann
 * @version 1.0
 */
class Lampe
{
    /** Farbe der Lampe wenn eingeschaltet */
    String farbe;
    /** Rahmenrechteck */
    Rechteck rahmen;
    /** Hintergrund */
    Rechteck fläche;
    /** Birne */
    Kreis anzeige;
    
    /**
     * Legt eine Lampe an der gegebenen Position an.
     * @param x x-Koordinate der Lampe
     * @param y y-Koordinate der Lampe
     * @param farbe Farbe der Lampe
     */
    Lampe(int x, int y, String farbe)
    {
        rahmen = new Rechteck();
        rahmen.PositionSetzen(x, y);
        rahmen.GrößeSetzen(20, 20);
        rahmen.FarbeSetzen("schwarz");
        fläche = new Rechteck();
        fläche.PositionSetzen(x + 1, y + 1);
        fläche.GrößeSetzen(18, 18);
        fläche.FarbeSetzen("weiß");
        anzeige = new Kreis();
        anzeige.RadiusSetzen(5);
        anzeige.PositionSetzen(x + 10, y + 10);
        anzeige.FarbeSetzen(farbe);
        this.farbe = farbe;
    }
    
    /**
     * Schaltet die Lampe ein
     */
    void Einschalten()
    {
        anzeige.FarbeSetzen(farbe);
    }
    
    /**
     * Schaltet die Lampe aus
     */
    void Ausschalten()
    {
        anzeige.FarbeSetzen("schwarz");
    }
    
    /**
     * Setzt die Position der Lampe
     * @param x x-Koordinate der Lampe
     * @param y y-Koordinate der Lampe
     */
    void PositionSetzen(int x, int y)
    {
        rahmen.PositionSetzen(x, y);
        fläche.PositionSetzen(x + 1, y + 1);
        anzeige.PositionSetzen(x + 10, y + 10);
    }
}
