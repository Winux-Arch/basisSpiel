/**
 * Eine Ampel verwendet zur Anzeige drei Lampen.
 * Die Ampel verwaltet ihre Position als Ganzes, ihre Ausrichtung und auch die 
 * nach den Verkehrsregeln möglichen Ampelphasen.
 * 
 * @author Albert Wiedemann
 * @version 1.0
 */
class Ampel extends Ereignisbehandlung
{
    /** Mögliche Werte sind die in Deutschland erlaubten Ampelphasen 
     * grün, gelb, rot und rotgelb.
     */
    String ampelphase;
    /** obere Lampe (rot) */
    Lampe lampeOben;
    /** mittlere Lampe (gelb) */
    Lampe lampeMitte;
    /** untere Lampe (grün) */
    Lampe lampeUnten;
    /** obere Lampe (rot) */
   
    /**
     * Konstruktor für Objekte der Klasse Ampel.
     */
    Ampel()
    {
        this(100, 100);
    }
   
    /**
     * Konstruktor für Objekte der Klasse Ampel 
     * mit folgenden Eingabewerten.
     * @param x - x-Position
     * @param y - y-Position
     */
    Ampel(int x, int y)
    {
        ampelphase = "rot";
        lampeOben = new Lampe(x, y, "rot");
        lampeMitte = new Lampe(x, y + 20, "gelb");
        lampeUnten = new Lampe (x, y + 40, "gruen");

        lampeOben.Einschalten();
        lampeMitte.Ausschalten();
        //Ergänzen
    }
  
    /**
     * Setzt die Position der Ampel.
     * @param x x-Position
     * @param y y-Position
     */
    void PositionSetzen(int x, int y)
    {
        if (x<=800 && x>=0 && y<=600 && y>=0)
        {
            lampeOben.PositionSetzen(x, y);
            lampeMitte.PositionSetzen(x, y + 20);
            //Ergänzen
        }
    }
           
    /**
     * Setzt die Ampel auf grün.
     */
    void GrünSetzen()
    {
        ampelphase = "grün";
        lampeOben.Ausschalten();
        lampeMitte.Ausschalten();
        //Ergänzen
    }
}
